import pyAesCrypt

buffersize = 64 * 1024 # ukuran file 64kb 

password = input("Masukkan password untuk Enkripsi atau Dekripsi file yang diinginkan : ")

# pilihan user input untuk Enkripsi dengan mengetik E,e atau D,d untuk Dekripsi
E_atau_D = str(input("Ketik E/e untuk Enkripsi atau D/d untuk Dekripsi file : ")).upper()

if(E_atau_D == "E"):
    #Enkripsi file
    try:
        pyAesCrypt.encryptFile("catatan.txt", "catatan.txt.aes", password, buffersize)
        print("file berhasil dienkripsi !!")
    except EOFError as error:
        print(error)
elif(E_atau_D == "D"):
    #Dekripsi file
    try:
        pyAesCrypt.decryptFile("catatan.txt.aes", "catatan.txt", password, buffersize)
        print("file berhasil didekripsi")
    except EOFError as error:
        print(error)

else :
    print("Silahkan pilih opsi E,e atau D,d !!")